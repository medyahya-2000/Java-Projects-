package jarvis.ui;

import jarvis.interpreter.JarvisInterpreter;

public class EnvironmentPanel extends DebugViewPanel{
	
	private static final long serialVersionUID = 1L;
	
	
	public EnvironmentPanel(JarvisInterpreter ji) {
		super(ji,"Environment");		
	}
	
	protected void initUI() {
		super.initUI();
		
		
	}
}
