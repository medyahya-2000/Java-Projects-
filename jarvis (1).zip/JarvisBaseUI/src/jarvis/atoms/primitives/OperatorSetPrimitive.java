package jarvis.atoms.primitives;

import java.util.ArrayList;

import jarvis.atoms.AbstractAtom;
import jarvis.atoms.ListAtom;
import jarvis.atoms.NullAtom;
import jarvis.atoms.ObjectAtom;
import jarvis.interpreter.JarvisInterpreter;

public class OperatorSetPrimitive extends PrimitiveOperationAtom{

	protected void init() {
		argCount = 2;
	}
	
	@Override
	protected AbstractAtom execute(JarvisInterpreter ji,ObjectAtom self) {
		
		// Obtenir la liste d'attribut la classe de notre objet
		ObjectAtom selfClass = self.getJarvisClass();
		ListAtom attributes = (ListAtom) selfClass.linearizeAttributes();
		
		// Si on recherche un attribut inexistant dans la classe, retourne une erreur
		int attributePos = attributes.find(ji.getArg());
		if (attributePos == -1) {
			throw new IllegalArgumentException("Primitive "+ji.getEnvironment().reverseLookup(this)+
					": Bad argument, unknown attribute");
		}
		
		// Sinon, red�finis les attributs selon un ArrayList modifi�
		ArrayList<AbstractAtom> copy = new ArrayList<AbstractAtom>(self.getValues());
		copy.set(attributePos, ji.getArg());
		self.setValues(copy);
		
		return new NullAtom();
	}

	@Override
	public String makeKey() {
		
		return "OperatorNewPrimitive";
	}

}
