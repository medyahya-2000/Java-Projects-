package jarvis.atoms.primitives.bool;

import java.util.ArrayList;

import jarvis.atoms.AbstractAtom;
import jarvis.atoms.BoolAtom;
import jarvis.atoms.ObjectAtom;
import jarvis.atoms.primitives.PrimitiveOperationAtom;
import jarvis.interpreter.JarvisInterpreter;

public class BoolPrimitiveNot extends PrimitiveOperationAtom {
	
	protected void init() {
		argCount = 0;
	}

	@Override
	public String makeKey() {
		return "BoolPrimitiveNot";
	}
	
	@Override
	protected AbstractAtom execute(JarvisInterpreter ji,ObjectAtom self) {
		BoolAtom selfBool = (BoolAtom) self.message("value");
		return calculateResult(ji, selfBool);
	}
	
	protected AbstractAtom calculateResult(JarvisInterpreter ji,BoolAtom selfBool) {
		ArrayList<AbstractAtom> data = new ArrayList<AbstractAtom>();
		data.add(new BoolAtom(!selfBool.getValue()));

		return new ObjectAtom(((ObjectAtom) ji.getEnvironment().get("bool")), data, ji);
	}

}
