package labo6;

import java.util.Random;

/*
 * D�finitions et fonctions utilitaires.
 */

public class Ressources {

	public enum Gender {
		male(0), female(1), unknown(2);

		public int value;

		private Gender(int v) {
			value = v;
		}
		
		public static Gender random(){
			Random generator = new Random();
				
			return values()[generator.nextInt(values().length)];
		}

	   public Gender getGender(int genderValue) {
		      for (Gender g : Gender.values()) {
		          if (g.value == value) {
		        	  return g;
		          }
		      }
			return null;
	   }
	}

	public enum Country {
		Canada(0), Quebec(1), France(2), Japan(3), UnitedStates(4);

		public int value;

		private Country(int v) {
			value = v;
		}

		public Country next() {

			return values()[(value + 1) % values().length];

		}
		
		   public Country getCountry(int countryValue) {
			      for (Country c : Country.values()) {
			          if (c.value == value) {
			        	  return c;
			          }
			      }
				return null;
		   }
	}

	

	public static final String[] flagImages = { "images/canflag.png", "images/quebecflag.png", "images/franceflag.png",
			"images/japflag.png", "images/usflag.png"

	};

	
	public static final String[] genderIcons = {

			"images/masicon.png", "images/femicon.png", "images/unkicon.png" };

	
}
