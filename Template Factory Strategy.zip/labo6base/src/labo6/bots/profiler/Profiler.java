package labo6.bots.profiler;

import labo6.User;
import labo6.Ressources.Country;
import labo6.Ressources.Gender;
import labo6.bots.ChatBot;
import labo6.bots.behavior.CheckUserBehaviorQuestion;
import labo6.bots.behavior.WaitBehaviorPatient;
import labo6.database.Picture;
import labo6.database.PictureDatabase;
import labo6.database.PictureList;
import labo6.database.TextDatabase;
import labo6.database.TextList;
import labo6.database.TextMessage.TextKey;

public abstract class Profiler {
	
	protected Gender gender;
	protected Country country;
	
	public String generateGreeting() {
		TextList list = getSuitableMessages();
		list.keep(TextKey.isGreeting, true);
		
		return list.random().getMessage();
	}
	
	
	public String generateAnswer() {
		return getSuitableMessages().random().getMessage();
	}
	
	public abstract PictureList getSuitablePictures();
	
	public abstract TextList getSuitableMessages();

	public abstract ChatBot createChatBot(User human, String name, Picture pic);
	
	public Gender getGender(){
		return gender;
	}

}
