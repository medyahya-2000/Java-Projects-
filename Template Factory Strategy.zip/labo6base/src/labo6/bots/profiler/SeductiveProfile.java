package labo6.bots.profiler;

import labo6.User;
import labo6.Ressources.Gender;
import labo6.bots.ChatBot;
import labo6.bots.behavior.CheckUserBehaviorDontCare;
import labo6.bots.behavior.WaitBehaviorImpatient;
import labo6.database.Picture;
import labo6.database.PictureDatabase;
import labo6.database.PictureList;
import labo6.database.TextDatabase;
import labo6.database.TextList;
import labo6.database.Picture.PictureKey;
import labo6.database.TextMessage.Language;
import labo6.database.TextMessage.TextKey;

public class SeductiveProfile extends Profiler {
	
	public SeductiveProfile(User human){
		if (human.getGender().value == 0) {
			gender = Gender.female;
		}
		if (human.getGender().value == 1) {
			gender = Gender.male;
		}
		if (human.getGender().value == 2) {
			gender = Gender.unknown;
		}
		country = human.getCountry();
	}
	
	@Override
	public PictureList getSuitablePictures() {
		PictureList list = PictureDatabase.getAllPictures();
		list.keep(PictureKey.isSeductive, true);
		list.keep(PictureKey.gender, gender.getGender(gender.value));
		if (country.value == 3) {
			list.keep(PictureKey.isComic, true);
		}
		
		return list;
	}
	
	@Override
	public TextList getSuitableMessages() {
		TextList list = TextDatabase.getAllMessages();
		
		list.keep(TextKey.isSeductive, true);
		
		if (country.value == 1 || country.value == 2) {
			list.keep(TextKey.language, Language.french);
		}
		else {
			list.keep(TextKey.language, Language.english);
		}
		
		return list;
	}
	
	@Override
	public ChatBot createChatBot(User human, String name, Picture pic) {
		return new ChatBot(this, new CheckUserBehaviorDontCare(), new WaitBehaviorImpatient(), human, name, pic, gender);
	}

}
