package labo6.bots.profiler;

import labo6.User;
import labo6.Ressources.Gender;
import labo6.bots.ChatBot;
import labo6.bots.behavior.CheckUserBehaviorRepeat;
import labo6.bots.behavior.WaitBehaviorSlowMo;
import labo6.database.Picture;
import labo6.database.PictureDatabase;
import labo6.database.PictureList;
import labo6.database.TextDatabase;
import labo6.database.TextList;
import labo6.database.Picture.PictureKey;
import labo6.database.TextMessage.Language;
import labo6.database.TextMessage.TextKey;

public class CasualProfile extends Profiler {
	
	public CasualProfile(User human){
		gender = Gender.random();
		country = human.getCountry();
	}

	@Override
	public PictureList getSuitablePictures() {
		PictureList list = PictureDatabase.getAllPictures();
		list.keep(PictureKey.isSeductive, false);
		list.keep(PictureKey.gender, gender.getGender(gender.value));
		if (country.value == 3) {
			list.keep(PictureKey.isComic, true);
		}
		
		return list;
	}
	
	@Override
	public TextList getSuitableMessages() {
		TextList list = TextDatabase.getAllMessages();
		
		list.keep(TextKey.isSeductive, false);
		
		if (country.value == 1 || country.value == 2) {
			list.keep(TextKey.language, Language.french);
		}
		else {
			list.keep(TextKey.language, Language.english);
		}
		
		return list;
	}
	
	@Override
	public ChatBot createChatBot(User human, String name, Picture pic) {
		return new ChatBot(this, new CheckUserBehaviorRepeat(), new WaitBehaviorSlowMo(), human, name, pic, gender);
	}
	
}
