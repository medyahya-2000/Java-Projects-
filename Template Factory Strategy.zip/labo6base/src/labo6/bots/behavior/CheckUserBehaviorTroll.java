package labo6.bots.behavior;

import labo6.database.TextList;
import labo6.database.TextMessage.TextKey;

public class CheckUserBehaviorTroll extends CheckUserBehavior {
	
	private int i = 0;

	@Override
	public boolean checkForWakeUp() {
		if (bot.getPeer().getLastLine().isEmpty())
			return false;
		else
			return true;
	}
	
}
