package labo6.bots.behavior;

import labo6.bots.ChatBot;

public class CheckUserBehaviorQuestion extends CheckUserBehavior {

	@Override
	public boolean checkForWakeUp() {
		return bot.getPeer().getLastLine().contains("?");
	}

}
