package labo6.bots.behavior;

import labo6.bots.ChatBot;

public class WaitBehaviorSlowMo extends WaitBehavior {

	@Override
	public void waitForUser() {
		bot.sleep(2000);	
	}
	
}
