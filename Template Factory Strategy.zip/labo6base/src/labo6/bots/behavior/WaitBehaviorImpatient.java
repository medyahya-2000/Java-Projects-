package labo6.bots.behavior;

import labo6.bots.ChatBot;

public class WaitBehaviorImpatient extends WaitBehavior {
	
	@Override
	public void waitForUser() {
		bot.sleep(1000);
		bot.appendMessage(bot.getProfiler().getSuitableMessages().random().getMessage());
	}
}
