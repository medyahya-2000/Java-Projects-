package labo6.bots.behavior;

import labo6.database.TextList;
import labo6.database.TextMessage.TextKey;

public class WaitBehaviorTroll extends WaitBehavior {
	
	private int i = 0;
	
	@Override
	public void waitForUser() {
		bot.sleep(1000);
		if (bot.getProfiler().getGender() == bot.getGender()) {
			bot.appendMessage(bot.getProfiler().getSuitableMessages().random().getMessage());
		}
		else {
			if (i >= 5) {
				TextList list = bot.getProfiler().getSuitableMessages();

				list.keep(TextKey.isPassiveAggressive, true);
				bot.appendMessage(list.random().getMessage());
			}
			else {
				bot.appendMessage(bot.getProfiler().getSuitableMessages().random().getMessage());
				i++;
			}
		}
	}
}
