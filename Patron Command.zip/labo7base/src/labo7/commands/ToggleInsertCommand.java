package labo7.commands;

import labo7.model.EditableDocument;
import labo7.ui.EditorCheckBox;

public class ToggleInsertCommand extends Command {
    EditableDocument doc;
    EditorCheckBox check;

    ToggleInsertCommand(EditableDocument a, EditorCheckBox b, CommandLog c) {
        super(c);
        doc = a;
        check = b;
    }

    @Override
    public void execute() {
        if (check.isSelected()) {
            doc.enableInsert();
        }
        else {
            doc.disableInsert();
        }
    }
}
