package labo7.commands;

import labo7.model.EditableDocument;
import labo7.ui.EditorTextArea;

public class CutEditDocumentCommand extends EditDocumentCommand {
    CutEditDocumentCommand(EditableDocument m, EditorTextArea n, CommandLog l) {
        super(m, n, l);
    }

    @Override
    public void execute() {
        exset = doc.getText();
        doc.cut(textArea.getSelectionStart(), textArea.getSelectionEnd());
        set = doc.getText();
        updateLog(this.clone());
    }
}
