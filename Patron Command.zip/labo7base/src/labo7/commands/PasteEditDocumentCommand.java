package labo7.commands;

import labo7.model.EditableDocument;
import labo7.ui.EditorTextArea;

public class PasteEditDocumentCommand extends EditDocumentCommand {
    PasteEditDocumentCommand(EditableDocument m, EditorTextArea n, CommandLog l) {
        super(m, n, l);
    }

    @Override
    public void execute() {
        exset = doc.getText();
        doc.paste(textArea.getSelectionStart());
        set = doc.getText();
        updateLog(this.clone());
    }
}
