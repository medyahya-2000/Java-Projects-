package labo7.commands;

import labo7.model.EditableDocument;
import labo7.ui.EditorCheckBox;
import labo7.ui.EditorTextArea;

public class CommandFactory {
    private static CopyEditDocumentCommand copyInstance;
    private static CutEditDocumentCommand cutInstance;
    private static MajEditDocumentCommand majInstance;
    private static MinEditDocumentCommand minInstance;
    private static PasteEditDocumentCommand pasteInstance;
    private static ToggleInsertCommand toggleInsertInstance;
    private static TwitEditDocumentCommand twitInstance;
    private static UndoCommand undoInstance;
    private static RedoCommand redoInstance;
    private static EditTextCommand textInstance;
    private static CommandLog logInstance;

    public static CopyEditDocumentCommand getCopyCommandInstance(EditableDocument m, EditorTextArea n) {
        if(copyInstance == null) {
            copyInstance = new CopyEditDocumentCommand(m, n, getCommandLogInstance());
        }
        return copyInstance;
    }

    public static CutEditDocumentCommand getCutCommandInstance(EditableDocument m, EditorTextArea n) {
        if(cutInstance == null) {
            cutInstance = new CutEditDocumentCommand(m, n, getCommandLogInstance());
        }
        return cutInstance;
    }

    public static MajEditDocumentCommand getMajCommandInstance(EditableDocument m, EditorTextArea n) {
        if(majInstance == null) {
            majInstance = new MajEditDocumentCommand(m, n, getCommandLogInstance());
        }
        return majInstance;
    }

    public static MinEditDocumentCommand getMinCommandInstance(EditableDocument m, EditorTextArea n) {
        if(minInstance == null) {
            minInstance = new MinEditDocumentCommand(m, n, getCommandLogInstance());
        }
        return minInstance;
    }

    public static PasteEditDocumentCommand getPasteCommandInstance(EditableDocument m, EditorTextArea n) {
        if(pasteInstance == null) {
            pasteInstance = new PasteEditDocumentCommand(m, n, getCommandLogInstance());
        }
        return pasteInstance;
    }

    public static ToggleInsertCommand getToggleInsertCommandInstance(EditableDocument m, EditorCheckBox _checkbox) {
        if(toggleInsertInstance == null) {
            toggleInsertInstance = new ToggleInsertCommand(m, _checkbox, getCommandLogInstance());
        }
        return toggleInsertInstance;
    }

    public static TwitEditDocumentCommand getTwitCommandInstance(EditableDocument m, EditorTextArea n) {
        if(twitInstance == null) {
            twitInstance = new TwitEditDocumentCommand(m, n, getCommandLogInstance());
        }
        return twitInstance;
    }

    public static UndoCommand getUndoCommandInstance() {
        if(undoInstance == null) {
            undoInstance = new UndoCommand(getCommandLogInstance());
        }
        return undoInstance;
    }

    public static CommandLog getCommandLogInstance() {
        if(logInstance == null) {
            logInstance = new CommandLog();
        }
        return logInstance;
    }

    public static RedoCommand getRedoCommandInstance() {
        if(redoInstance == null) {
            redoInstance = new RedoCommand(getCommandLogInstance());
        }
        return redoInstance;
    }

    public static EditTextCommand getTextCommandInstance(EditableDocument m, EditorTextArea n) {
        if(textInstance == null) {
            textInstance = new EditTextCommand(m, n, getCommandLogInstance());
        }
        return textInstance;
    }
}