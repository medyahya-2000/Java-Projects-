package labo7.commands;

public class UndoCommand extends Command {
    UndoCommand(CommandLog l) {
        super(l);
    }

    @Override
    public void execute() {
        log.undo();
    }
}
