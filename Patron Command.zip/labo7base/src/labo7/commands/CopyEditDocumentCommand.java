package labo7.commands;

import labo7.model.EditableDocument;
import labo7.ui.EditorTextArea;

public class CopyEditDocumentCommand extends EditDocumentCommand {
    CopyEditDocumentCommand(EditableDocument d, EditorTextArea _textArea, CommandLog _log) {
        super(d, _textArea, _log);
    }

    @Override
    public void execute() {
        exset = doc.getText();
        doc.copy(textArea.getSelectionStart(), textArea.getSelectionEnd());
        set = doc.getText();
        updateLog(this.clone());
    }
}
