package labo7.commands;

public abstract class Command {
    protected CommandLog log;

    protected Command(CommandLog l) {
        log = l;
    }

    public abstract void execute();
}