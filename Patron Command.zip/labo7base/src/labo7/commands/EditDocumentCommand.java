package labo7.commands;

import labo7.model.EditableDocument;
import labo7.ui.EditorTextArea;

public abstract class EditDocumentCommand extends Command implements Cloneable {
    protected EditableDocument doc;
    protected  EditorTextArea textArea;
    protected String exset;
    protected  String set;

    EditDocumentCommand(EditableDocument m, EditorTextArea n, CommandLog l) {
        super(l);
        doc = m;
        textArea = n;
        exset = null;
    }

    public abstract void execute();

    public void undo() {
        doc.setText(exset);
    }

    public void redo() {
        doc.setText(set);
    }

    @Override
    protected EditDocumentCommand clone() {
        try {
            return (EditDocumentCommand)super.clone();
        }
        catch (CloneNotSupportedException e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    protected void updateLog(EditDocumentCommand c) {
        log.add(c);
        log.emptyRedo();
    }
}
