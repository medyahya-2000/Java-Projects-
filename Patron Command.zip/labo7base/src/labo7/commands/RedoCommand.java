package labo7.commands;

public class RedoCommand extends Command {
    RedoCommand(CommandLog l) {
        super(l);
    }

    @Override
    public void execute() {
        log.redo();
    }
}
