package labo7.commands;

import labo7.model.EditableDocument;
import labo7.ui.EditorTextArea;

public class EditTextCommand extends EditDocumentCommand {
    EditTextCommand(EditableDocument m, EditorTextArea n, CommandLog l) {
        super(m, n, l);
    }

    @Override
    public void execute() {
        exset = doc.getText();
        doc.setText(textArea.getText());
        set = doc.getText();
        updateLog(this.clone());
    }
}