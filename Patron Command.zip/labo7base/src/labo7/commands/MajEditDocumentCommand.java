package labo7.commands;

import labo7.model.EditableDocument;
import labo7.ui.EditorTextArea;

public class MajEditDocumentCommand extends EditDocumentCommand {
    MajEditDocumentCommand(EditableDocument m, EditorTextArea n, CommandLog l) {
        super(m, n, l);
    }

    @Override
    public void execute() {
        exset = doc.getText();
        doc.capitalize(textArea.getSelectionStart(), textArea.getSelectionEnd());
        set = doc.getText();
        updateLog(this.clone());
    }
}
