package labo7.commands;

import labo7.model.EditableDocument;
import labo7.ui.EditorTextArea;

public class TwitEditDocumentCommand extends EditDocumentCommand {
    TwitEditDocumentCommand(EditableDocument m, EditorTextArea n, CommandLog l) {
        super(m, n, l);
    }

    @Override
    public void execute() {
        if(doc.getText().length() > 140) {
            exset = doc.getText();
            doc.setText(doc.getText().substring(0, 140));
            set = doc.getText();
            updateLog(this.clone());
        }
    }
}
