package labo7.commands;

import java.util.Stack;

public class CommandLog {
    private Stack<EditDocumentCommand> undoCommands = new Stack();
    private Stack<EditDocumentCommand> redoCommands = new Stack();

    public void add(EditDocumentCommand c) {
        undoCommands.add(c);
    }

    public void undo() {
        if(!undoCommands.isEmpty()) {
            EditDocumentCommand c = undoCommands.pop();
            c.undo();
            redoCommands.add(c);
        }
    }

    public void redo() {
        if(!redoCommands.isEmpty()) {
            EditDocumentCommand c = redoCommands.pop();
            c.redo();
            undoCommands.add(c);
        }
    }

    public boolean isUndoEmpty() {
        return undoCommands.isEmpty();
    }

    public boolean isRedoEmpty() {
        return redoCommands.isEmpty();
    }

    public void emptyRedo() {
        redoCommands.clear();
    }
}
