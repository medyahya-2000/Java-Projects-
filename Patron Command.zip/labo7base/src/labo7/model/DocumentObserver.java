package labo7.model;

/*
 * Interface pour les observateurs du document.
 */
public interface DocumentObserver {
	void update();
	void setModel(EditableDocument doc);
}
