package labo7.ui;

import labo7.commands.Command;

public interface Invoker {
    void storeCommand(Command c);
}
