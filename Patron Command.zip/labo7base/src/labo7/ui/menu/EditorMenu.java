package labo7.ui.menu;

import labo7.commands.CommandFactory;
import labo7.ui.EditorTextArea;

import javax.swing.JPopupMenu;

public class EditorMenu extends JPopupMenu {
	private static final long serialVersionUID = 1L;
	private EditorTextArea textArea;

	public EditorMenu(EditorTextArea texta) {
		textArea = texta;
	}

	public boolean hasSelection() {
		return this.textArea.getSelectedText() != null;
	}

	public boolean isUndoLogEmpty() {
		return CommandFactory.getCommandLogInstance().isUndoEmpty();
	}

	public boolean isRedoLogEmpty() {
		return CommandFactory.getCommandLogInstance().isRedoEmpty();
	}
}
